/*
 * Name : Dhruv Saksena
 * andrew_id : dsaksena
 *  
 * Name : Kavya Srinet
 * andrew_id : ksrinet
 *
 *
 * init_cache - initialize the cache
 * and return a pointer to the cache
 */

#include "cache.h"

cache *init_cache() {
  
	  cache *cache_n = (cache *)malloc(sizeof(cache));
	  cache_n->head = NULL;
	  cache_n->tail = NULL;
	  cache_n->delta_size = MAX_CACHE_SIZE;
    pthread_rwlock_init(&cache_n->lock,NULL);
	  return cache_n;
}

/*
 * free_obj - Free a web object and memory 
 * allocated to it
 */
void free_obj(web_obj *obj){
	  if (obj == NULL){
        return;
  	}
	  Free(obj->id);
	  Free(obj->content);
	  Free(obj);
}

/*
 * search_for_obj - Search for a  web object in cache
 * using the id of the object   
 */
web_obj *search_for_obj(cache *cache_n, char *id){
	  web_obj *obj = cache_n->head;
	  while (obj != NULL){
	      if (strcmp(obj->id, id) == 0) { /*if ids match, return the object*/
        		return obj;
	      }
        obj = obj->next;
	  }
	  return NULL;/*object not found, return NULL*/
}

/*
 * add_obj - Add a web object to the cache
 * we add at the tail
 */
void add_obj(cache *cache_n, web_obj *obj){
	  if(cache_n->head == NULL){ /*if cache is empty*/
        /*head and tail both point to the obj*/
	      cache_n->head = cache_n->tail = obj; 
        /*update remiaining size to be size minus content size of obj*/     
	      cache_n->delta_size -= obj->cont_size; 
	  }
    else {
       	cache_n->tail->next = obj;/*add at the tail*/
		    cache_n->delta_size -= obj->cont_size;
	      cache_n->tail = obj;
        cache_n->tail->next = NULL;     
	  }
}

/*
 * evict_and_add - If the cache does not have enough space to
 * accomodate a web object, evict till there is enough space
 * and then add the object to the cache
 */
void evict_and_add(cache *cache_n, web_obj *obj) {
    pthread_rwlock_wrlock(&cache_n->lock);
	  /*lock the eviction process*/
	  while(cache_n->delta_size < obj->cont_size){ 
        /*while remianing space in cache < content size of obj*/
        if(cache_n->head == NULL){
            pthread_rwlock_unlock(&cache_n->lock);
            printf("Too Big to cache\n");
            return;
        }
       	evict_obj(cache_n);
	  }
	  add_obj(cache_n, obj);/*now cache has sufficicnet space to hold the obj*/
    pthread_rwlock_unlock(&cache_n->lock);
}

/*
 * evict_obj - delete an object from the head of cache
 * as we are inserting a new obj at the tail, this should
 * serve the lru policy
 */
void evict_obj(cache *cache_n){
	  web_obj *obj = cache_n->head;
    if(obj != NULL) {/*if cache list empty*/
        cache_n->head = obj->next; /*update head and remianing size of cache*/
      	cache_n->delta_size += obj->cont_size;
        if(obj == cache_n->tail){
            /*if this is the last node in cache, update tail too*/
            cache_n->tail = NULL;
        }
	  }
    free_obj(obj); /*Now free the memory allocated to the object*/
}

/*
 * delete_obj - delete an obj with a given id
 * and update the cache, and retur a pointer to the ibj deleted
 */
web_obj *delete_obj(cache *cache_n, char *id){
	  web_obj *obj_prev = NULL;
	  web_obj *obj = cache_n->head;
	  while(obj != NULL){
	      if(strcmp(obj->id, id) == 0) {
            /*obj found, then update cache and delete*/ 
		        if(obj == cache_n->head){ /*if head node, update head ptr*/
             		cache_n->head = obj->next;
			      }
			      if(obj == cache_n->tail){ /*if tail node, update tail node*/
         		    cache_n->tail = obj_prev;
            }
			      cache_n->delta_size += obj->cont_size;
            /*update remaining size of cache*/
			      if(obj_prev != NULL){/*if in middle, update previous obj*/
                obj_prev->next = obj->next;
            }
            return obj;
  	    }
        obj_prev = obj;
        obj = obj->next;
    }
	  return NULL; /*obj not found in cache, return NULL*/
}

/*
 * check_cache_for_obj - This function looks up the cache, to find
 * a web object with the id 'id', if found, it repositions the object
 * in the cache to adhere to lru policy
 */
int check_cache_for_obj(cache *cache_n, char *id,
 void *content, unsigned int *length) {
 
    pthread_rwlock_rdlock(&cache_n->lock);
	  if(cache_n == NULL){
        pthread_rwlock_unlock(&cache_n->lock); 
	      return -1;
	  }
    /*search for the node with the id*/ 
	  web_obj *obj = search_for_obj(cache_n, id);
	  if(obj == NULL) {/*if obj not found in cache*/
        pthread_rwlock_unlock(&cache_n->lock); 
	      return -1;
	  }
	  /* otherwise, we have now found the object, map it to virtual address space
	   * delete it from Cache and place it at the end of the cache, to
	   * stick to the LRU policy, ensuring , last read object is at the head
	   */
	  *length = obj->cont_size;
	  memcpy(content, obj->content, *length);
    pthread_rwlock_unlock(&cache_n->lock);
   
	  /* Now we update the postion of object in cache
	   * as it was recently updated, so we add it at the tail of the cache
  	 */
    pthread_rwlock_wrlock(&cache_n->lock);
	  obj = delete_obj(cache_n, id);
	  add_obj(cache_n, obj);
    pthread_rwlock_unlock(&cache_n->lock);
	
 
  	return 0;
}

/*
 *  add_obj_to_cache - This function adds a web object with id 'id'
 *  to the cache, as it was recently referenced and was not found in the cache
 *  it checks if enough space is available in cache, otherwise it evicts
 *  and then adds it to cache
 */
int add_obj_to_cache(cache *cache_n, char *id,
 void *content, unsigned int length) {
  
	  if(cache_n == NULL) {
		    return -1;
	  }
	  web_obj *obj = (web_obj *)malloc(sizeof(web_obj));
    /*Malloc a length of id*/
    obj->id = (char *)Malloc(sizeof(char) * (strlen(id) + 1)); 
    obj->cont_size = 0;
    obj->content = Malloc(length); /*malloc memory equal to content length*/
    obj->next = NULL;
    strcpy(obj->id, id);
	  memcpy(obj->content, content, length);
	  obj->cont_size = length;
	  evict_and_add(cache_n, obj);
  
	  return 0;
}

