/*
 * Name : Dhruv Saksena
 * andrew_id : dsaksena
 *  
 * Name : Kavya Srinet
 * andrew_id : ksrinet
 * 
 *
 * proxy.c implements a simple web proxy that handles GET requests, and 
 * reads up the client's buffer and first checks if it has the object
 * cached in its cache, if yes, it replies back with the cached object
 * otherwise it sends a request forward to the server, and thenm updates its
 * cache with the responded object and then sends/
 * forwards the response from server to client
 *
 * The proxy also keeps a check on object size, we use a thread each to deal
 * with concurrent requests while making sure that the cache is thread safe
 */


#include <stdio.h>
#include "csapp.h"
#include "cache.h"

/* Recommended max cache and object sizes */
#define MAX_CACHE_SIZE 1049000
#define MAX_OBJECT_SIZE 102400

/* You won't lose style points for including these long lines in your code */
static const char *user_agent_hdr = "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:10.0.3) Gecko/20120305 Firefox/10.0.3\r\n";
static const char *accept_hdr = "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8\r\n";
static const char *accept_encoding_hdr = "Accept-Encoding: gzip, deflate\r\n";
static const char *connection = "Connection: close\r\n";
static const char *proxy_connection = "Proxy-Connection: close\r\n";

cache *cache_n = NULL;

void doit(int *fd);
void read_requesthdrs(rio_t *rp, char buffer[MAXLINE]);
void parse_url(char buffer[MAXLINE], char* hostname, char* path, int *port);
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg);
void get_content_size(char *buf, unsigned int *size_pointer);      
int serve_from_cache(int to_client_fd, void *cache_content,
 unsigned int cache_length);
int append_response(char *content, unsigned int *cont_size, char *buf,
 unsigned int buf_len);

int main(int argc, char **argv)
{
    printf("%s%s%s", user_agent_hdr, accept_hdr, accept_encoding_hdr);
    Signal(SIGPIPE, SIG_IGN);
    pthread_t tid;    
        
    int listenfd, *connfd, port, clientlen;
    struct sockaddr_in clientaddr;

    /* Check command line args */
    if (argc != 2) {
        fprintf(stderr, "usage: %s <port>\n", argv[0]);
	      exit(1);
    }
    port = atoi(argv[1]);
    if (port == 0) {
        	fprintf(stderr, "Invalid port number\n");
        	exit(1);
	  }
     
    cache_n = init_cache(); 
    listenfd = Open_listenfd(port);
    printf("Proxy Started!\n==========================\n");    
    while (1) {
	      clientlen = sizeof(clientaddr);
        connfd = (int *)malloc(sizeof(int));             
	      *connfd = Accept(listenfd, (SA *)&clientaddr, (socklen_t *)&clientlen);
        Pthread_create(&tid, NULL, (void *)doit, (void *)connfd);             
    }
    
    return 0;
    
}

/*
 * doit - handle one HTTP request/response transaction
 */
/* $begin doit */
void doit(int *fd2) 
{
    Pthread_detach(pthread_self());/*Make the thread detached*/
   	int fd = *(int *)fd2;/*fetch client_fd and free the previous connfd*/
	  Free((void *)fd2);
    
    char port_num[15];        
    char buf[MAXLINE], method[MAXLINE], uri[MAXLINE];
    char hostname[MAXLINE], version[MAXLINE], bufc[MAXLINE];
    char path[MAXLINE], content[MAX_OBJECT_SIZE];
    char id[MAXLINE]; /* id of the web object*/
    int port = 80,fit = 1;
    int server_fd;    
    unsigned int size = 0, bytes = 0, cont_size = 0;
    
    rio_t rio,server_connection;
  
    /* Read request line and headers */
    Rio_readinitb(&rio, fd);
    Rio_readlineb(&rio, bufc, MAXLINE);
    
    sscanf(bufc, "%s %s %s", method, uri, version);
    parse_url(bufc, hostname, path, &port);   
     
    if (strcmp(bufc, "GET http:") == 0) { 
        clienterror(fd, method, "501", "Not Implemented",
                "Proxy does not implement this method, only GET http:");
                printf("NON GET \n");
        close(fd);
        return;
    }
    sprintf(port_num, "%d", port);
    /* We make the id of a web object to check its presence in the cache*/
    strcpy(id, method);
    strcat(id, " ");
    strcat(id, hostname);
    strcat(id, ":");
    strcat(id, port_num);
    strcat(id, path);
    strcat(id, " ");
    strcat(id, version);
       
    /*See if the object is in the cache, if present,
     * update its content and content length*/
    if (check_cache_for_obj(cache_n, id, content, &cont_size) != -1) {
    /*object found in cache*/
        if (serve_from_cache(fd, content, cont_size) == -1){ 
	          close(fd);
	          Pthread_exit(NULL);
	      }
        close(fd);
        return;            
    }
    
    /* connecting to server */
    if((server_fd = open_clientfd_r(hostname, port)) < 0){
        char errorbuf[] = "HTTP 404 NOTFOUND\r\n\r\n404 Not Found\r\n";
        Rio_writen(fd, errorbuf, strlen(errorbuf));
        close(fd);
        return;
    }
    
    Rio_readinitb(&server_connection, server_fd);
    
    /* sending server GET request */
    Rio_writen(server_fd, "GET ", strlen("GET "));
    Rio_writen(server_fd, path, strlen(path));
    Rio_writen(server_fd, " HTTP/1.0", strlen(" HTTP/1.0"));
    Rio_writen(server_fd, "\r\n", strlen("\r\n"));
    
    /* sending server headers */    
    
    strcpy(buf, user_agent_hdr);
    strcat(buf, accept_hdr);    
    strcat(buf, accept_encoding_hdr);
    strcat(buf, connection);
    strcat(buf, proxy_connection);
    read_requesthdrs(&rio, buf);    
    Rio_writen(server_fd, buf, strlen(buf)); 
   	Rio_writen(server_fd, "\r\n", 2);   
        
     
    if (Rio_readlineb(&server_connection, buf, MAXLINE) == -1) {
        close(fd);
        close(server_fd);
        Pthread_exit(NULL);
    }     
    
    /* After reading, we update the content to append the data in it,
  	 * so we can later add the reposnse as a content to the cache web object
  	 */
  	if (fit){/*size within limits, append the status to content of web object*/
  	    fit = append_response(content, &cont_size, buf, strlen(buf));
        /*check flag for updated size*/
  	}
   
   
    /* Now first we read the status line in it*/    
    if (Rio_writen(fd, buf, strlen(buf)) == -1) {/*Now write to client's buf*/
        close(fd);
        close(server_fd);
        Pthread_exit(NULL);       
    } 
    while (strcmp(buf, "\r\n") != 0 && strlen(buf) > 0){
     	if (Rio_readlineb(&server_connection, buf, MAXLINE) == -1){
          close(fd);
          close(server_fd);
          Pthread_exit(NULL);    
     	}
		  if (Rio_writen(fd, buf, strlen(buf)) == -1) {
          close(fd);
          close(server_fd);
          Pthread_exit(NULL);                  
		  }
      if (fit) {
         		fit = append_response(content, &cont_size, buf, strlen(buf));
      }
		  get_content_size(buf, &size); 
      /*If there is response body, fetch the size*/
    }
    
    /* Now we read the response body*/
	  if (size > 0){ /*If there is a response body*/
        while (size > MAXLINE){
        /*read it MAXLINE by MAXLINE, write to cache, and update content*/
            if ((bytes =  Rio_readnb(&server_connection, buf, MAXLINE)) == -1){
                close(fd);
                close(server_fd);
                Pthread_exit(NULL);
            }
  			    if (Rio_writen(fd, buf, bytes) == -1) {
                close(fd);
                close(server_fd);
                Pthread_exit(NULL);
            }  	
            if (fit) {
             		fit = append_response(content, &cont_size, buf, bytes);
            }		    
            size -= MAXLINE;
       	}
        if (size > 0){ 
        /*if some delta size is left < MAXLINE, read byte by byte,
         * write and update content
         */
         		if ((bytes = Rio_readnb(&server_connection, buf, size)) == -1){
                close(fd);
                close(server_fd);
                Pthread_exit(NULL);
         		}
  			    if (Rio_writen(fd, buf, bytes) == -1) {
                close(fd);
                close(server_fd);
                Pthread_exit(NULL);                          
  			    }  
            if (fit) {
         		    fit = append_response(content, &cont_size, buf, bytes);
            }          
        }
  	} 
    else{ 
    /*If there is no content body,
     * we read the residual data after response header
     */
		    while ((bytes =  Rio_readnb(&server_connection, buf, MAXLINE)) > 0) {
			      if (Rio_writen(fd, buf, bytes) == -1) {
                close(fd);
                close(server_fd);
                Pthread_exit(NULL);                            
  			    }
            if (fit) {
             		fit = append_response(content, &cont_size, buf, bytes);
            }     
   	    }
 	  }
   	
    /*If the updated content's value is <= MAX_OBJ_SIZE,
     * we add it to the cache now
     */
  	if (fit){
       	if (add_obj_to_cache(cache_n, id, content, cont_size) == -1) {
        printf("\ncache update error\n");
       	}
    }  

    close(fd);
    close(server_fd);    
    return;    
}
/* $end doit */

/*
 * read_requesthdrs - read and parse HTTP request headers
 */
/* $begin read_requesthdrs */
void read_requesthdrs(rio_t *rp, char buffer[MAXLINE]) 
{

    char buf[MAXLINE];
    Rio_readlineb(rp, buf, MAXLINE);   
    while(strcmp(buf, "\r\n")) {
        if(!strncmp(buf, "User-Agent:",11)){
        }
        else if(!strncmp(buf, "Host:",5)){
            strcat(buffer, buf); 
        }        
        else if(!strncmp(buf, "Connection:",11)){
        }
        else if(!strncmp(buf, "Proxy-Connection:",17)){
        }
        else if(!strncmp(buf, "Accept:",7)){
        }
        else if(!strncmp(buf, "Accept-Encoding:",16)){
        }                        
        else{
            strcat(buffer, buf); 
        }
        Rio_readlineb(rp, buf, MAXLINE);     
    }
}
/* $end read_requesthdrs */

/*
 * serve_from_cache - This function serves the client request
 * from a web object entry located in the cache without fetching it
 * again from the server
 */
int serve_from_cache(int client_fd, void *content, unsigned int cont_size){
  	/* send data to cache from cache*/
	  if (Rio_writen(client_fd, content, cont_size) == -1){
	      return -1;
	  }
	  return 0;
}

/*
 * append_response - Append the content of buf to the content of object
 * if the total size is > MAX_OBJECT_SIZE then an error, return 0
 * else append it to the content of object and update the pointer
 * return 1 on success
 */
int append_response(char *content, unsigned int *cont_size,
 char *buf, unsigned int buf_size) {
  	if ((*cont_size + buf_size) <= MAX_OBJECT_SIZE){
  	    void *ptr = (void *)((char *)content + *cont_size);
       	memcpy(ptr, buf, buf_size);
       	*cont_size = *cont_size + buf_size;
      	return 1;
	  }
	  return 0;
}

/*
 * get_cont_size - Fetch the content length from buf
 */
void get_content_size(char *buf, unsigned int *size_pointer) {
    if (strstr(buf, "Content-Length")){
        sscanf(buf, "Content-Length: %d", size_pointer);
    }
}



//parse a URL and set the hostname and path into the given buffers
void parse_url(char buffer[MAXLINE], char* hostname, char* path, int *port)
{
    //now let's copy out the hostname

    memset(hostname, '\0', MAXLINE*sizeof(char));
    memset(path, '\0', MAXLINE*sizeof(char));

    int i = 11; //first character after "GET http://"
    while(buffer[i] == '/')
    {
        i++; //this accounts for GET/POST and https
    }
    while(buffer[i] &&
            (buffer[i] != '/') &&
            (buffer[i] != ':'))
    {
        hostname[i-11] = buffer[i];
        i++;
    }
    if(buffer[i] == ':')
    {
        sscanf(&buffer[i+1], "%d%s", port, path);
    }
    else
    {
        sscanf(&buffer[i], "%s", path);
    }

    hostname[i-11] = '\0';
}

/*
 * clienterror - returns an error message to the client
 */
/* $begin clienterror */
void clienterror(int fd, char *cause, char *errnum, 
		 char *shortmsg, char *longmsg) 
{
    char buf[MAXLINE], body[MAXBUF];

    /* Build the HTTP response body */
    sprintf(body, "<html><title>Tiny Error</title>");
    sprintf(body, "%s<body bgcolor=""ffffff"">\r\n", body);
    sprintf(body, "%s%s: %s\r\n", body, errnum, shortmsg);
    sprintf(body, "%s<p>%s: %s\r\n", body, longmsg, cause);
    sprintf(body, "%s<hr><em>The Tiny Web server</em>\r\n", body);

    /* Print the HTTP response */
    sprintf(buf, "HTTP/1.0 %s %s\r\n", errnum, shortmsg);
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-type: text/html\r\n");
    Rio_writen(fd, buf, strlen(buf));
    sprintf(buf, "Content-length: %d\r\n\r\n", (int)strlen(body));
    Rio_writen(fd, buf, strlen(buf));
    Rio_writen(fd, body, strlen(body));
}
/* $end clienterror */