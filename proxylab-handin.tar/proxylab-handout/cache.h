/*
 * Name : Dhruv Saksena
 * andrew_id : dsaksena
 *  
 * Name : Kavya Srinet
 * andrew_id : ksrinet
 *
 *
 * Define a web object that the web proxy will deal with
 * every object has an id, content , size of content and 
 * pointer to the next object
 */
 
#include "csapp.h" 
 
typedef struct web_obj{
	  char *id;
	  void *content;
    unsigned cont_size;
	  struct web_obj *next;
} web_obj;

/* For our convenience , we declare the cache as a linked list
 * of web objects, the cache has a pointer to the head and tail of the list
 * the semaphores for reading and writng and the remaining length in the cache
 */
typedef struct cache{
  	web_obj *head; /*Head of the list*/
  	web_obj *tail; /*Tail of the list of web objects in cache*/
  	unsigned delta_size; /*remaining size*/
    /*lock to monitor updating  and writing to the cache*/
    pthread_rwlock_t lock;
} cache;

#define MAX_CACHE_SIZE 1049000 /*maximum size of cache is 1MB*/
#define MAX_OBJECT_SIZE 102400 /*maximum size of a web object is 1KB*/



/*functions used to manipulate and update the cache*/
cache *init_cache(); /*initialize the cache*/
web_obj *search_for_obj(cache *cache_n, char *id);/*search for a 
web object with id*/
void free_obj(web_obj *node); /*free the memory allocated to a web object*/
void add_obj(cache *cache_n, web_obj *node); /*add an object to the rear*/
void evict_and_add(cache *cache_n, web_obj *obj); /*evict if possible 
and then add*/
void evict_obj(cache *list);/*evict and object from cache*/
web_obj *delete_obj(cache *list, char *id);

int check_cache_for_obj(cache *cache_n, char *id,
 void *content, unsigned int *length); /*
 check if obj is present in cache, and reposition*/
int add_obj_to_cache(cache *cache_n, char *id, void *content,
 unsigned int length); /*add an object to cache*/

