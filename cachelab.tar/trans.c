/* Name : Kavya Srinet
 * andrew id: ksrinet
 *
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"
#include "contracts.h"

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. The REQUIRES and ENSURES from 15-122 are included
 *     for your convenience. They can be removed if you like.
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
 	int i,j, a, b;
	int temp_0, temp_1, temp_2, temp_3, temp_4, temp_5, temp_6, temp_7;
	REQUIRES(M > 0);
	REQUIRES(N > 0);
	
	/*Optimize the case of 32 x 32*/
	if((N == 32) && (M == 32)){
		/*The cache can store a total of 32x8 integers at a time. 
 		* Here we take blocks of 8x8, as the set number starts repeating after the 8th line causing more conflict misses
 		*/
		for(a = 0; a < N ; a += 8){ //traverse from column 0 to column 31 in blocks of 8
			for(b = 0; b < M ; b += 8){ //traverse from row 0 to row M-1 in blocks of 8 and traverse the blocks from top to bottom in the matrix
				for(i = b; i < (b + 8); i ++){ //traverse each row in the block
					for(j = a; j < (a + 8); j ++){ //traverse each column in the block
						/*Not diagonal, transpose, so, B[j][i] = A [i][j]*/
						if(i != j){
							B[j][i] = A[i][j];
						}
						//if diagonal save the index and element to avoid cache misses
						else{
							temp_0 = i; //diagonal index
							temp_1 = A[i][j]; //diagonal element
						}
					}
					//update the diagonal element in B
					if(a == b){
						B[temp_0][temp_0] = temp_1;
					}
				}
			}
		}	
	}
	/*Opimize the case of a matrix transpose of 64x64
	*In this case we take 8x8 blocks and split them into 4 4x4 blocks, and transpose each seperately
	*The sets in this case start repeating after the 4th line, causing conflict misses after the 4th line*/ 	
	else if(M==64 && N ==64){
		for(a = 0; a < N ; a += 8){ //traverse from column 0 to column 63  in blocks of 8
			for(b = 0; b < M ; b += 8){ //traverse from row 0 to row 63 in blocks of 8
                        	j = a+4;
                                /*Traverse and transpose the top left and right 4x4 blocks in A
                                * store the transposed form in B, with the top left blockat expected location and the right block on top right
                                * say the 8x8 block was 1 2 where 1, 2 3 and 4 are 4x4 blocks
                                *                       3 4
                                * Now in B it will be  1 2
                                *                      3 4 where 1 and 2 4x4 blocks are already transposed.*/
                                for(i = b; i < (b + 4); i++){ //traverse in a 4x4 block manner in 8x8 block
                                        //traverse and get the elements rowwise for the top left 4x4 block in the 8x8 block, for a particular column i//
                                	temp_0 = A[a][i];
				        temp_1 = A[a + 1][i];
                                        temp_2 = A[a+2][i];
                                        temp_3 = A[a+3][i];
                                        // traverse and get the elements rowwise for top right 4x4 block in the block , so i = i +4//
                                        temp_4 = A[a][i+4];
                                        temp_5 = A[a+1][i+4];
                                	temp_6 = A[a+2][i+4];
                                        temp_7 = A[a+3][i+4];
                                        //Now store the elements of top left transposed 4x4 A in B//
                                        B[i][a] = temp_0;
                                        B[i][a+1] = temp_1;
                                        B[i][a+2] = temp_2;
                                        B[i][a+3] = temp_3;
                                        //Store transpose of top right 4x4 from A to B
                                        B[i][a+4] = temp_4;
                                        B[i][a+5] = temp_5;
                                        B[i][a+6] = temp_6;
                                        B[i][a+7] = temp_7;
                                }
                                
				/*Now we traverse and transpose the bottom left 4x4 block in A
                                *Switch the previously located top right block in B to bottom left (correct position)
                                *Also we keep the transposed bottom left 4x4 block in A at thr right location in B (top right)
                                *After the whole step our 8x8 block will be 1 3
                                *                                           2 4 where 1 ,2and 3 are all transposed blocks and blok 4 is not yet transposed*/
                                for(i=b;i<(b+4);i++){
					//Get the elements in the bottom left 4x4 columnwise
					temp_0 = A[j][i];
					temp_1 = A[j+1][i];
					temp_2 = A[j+2][i];
					temp_3 = A[j+3][i];
					//Get the eleemnts from the top right 4x4 blck from B
					temp_4 = B[i][j];
					temp_5 = B[i][j+1];
					temp_6 = B[i][j+2];
					temp_7 = B[i][j+3];
					//Now store the transposed elements of bottom left block from A to top right block in B
					B[i][j] = temp_0;
					B[i][j+1] = temp_1;
					B[i][j+2] = temp_2;
					B[i][j+3] = temp_3;
					//Get the lements from top right 4x4 block of B and place them in bottom left 4x4 block of B
					B[i+4][a] = temp_4;
					B[i+4][a+1] = temp_5;
					B[i+4][a+2] = temp_6;
					B[i+4][a+3] = temp_7;
				}
			
				/*Now we traverse and transpose the bottom right 4x4 block in A and trasfer it to the bottom right 4x4 block in B
				* After traversing the for loop we will have the 8x8 block in B as 1 2
				* 								    3 4 where all 1,2,3 and 4 are all transposed*/
				for(i=b+4; i < b+8;i+=2){ //we increment i twice as we can now process 2 rows at a time in A
					//Get the elements from the first column of the block from A
					temp_0 = A[j][i];
					temp_1 = A[j+1][i];
					temp_2 = A[j+2][i];
					temp_3 = A[j+3][i];
					//Get the elements from the second column of the block from A
					temp_4 = A[j][i+1];
					temp_5 = A[j+1][i+1];
					temp_6 = A[j+2][i+1];
					temp_7 = A[j+3][i+1];
					//Transpose and move the elements to bottom right 4x4 block in B
					B[i][j] = temp_0;
					B[i][j+1] = temp_1;
					B[i][j+2] = temp_2;
					B[i][j+3] = temp_3;
					B[i+1][j] = temp_4;
					B[i+1][j+1] = temp_5;
					B[i+1][j+2] = temp_6;
					B[i+1][j+3] = temp_7;
				}
			}
		}				
	
	}	      
	/*optimize the 61x67 matrix and its transpose
	 *here we have 8*7 + 5 columns and 8*8 + 3 columns 
	 *We fetch elements in the same row, 8 at a time*/
	else if(M == 61 && N == 67){
		for(a = 0; a < M ; a += 8){ //traverse columnwise in blocks of 8
                        for(b = 0; b < N; b++){ //traverse one full row of 8 columns
        			//Fetch the 8 elements in matrix A rowwise in row b
        			temp_0 = A[b][a];
				temp_1 = A[b][a+1];
				temp_2 = A[b][a+2];
				temp_3 = A[b][a+3];
				temp_4 = A[b][a+4];
				//For all blocks in A except the last(starting with column 56th) we will have 8 columns but the 8th block has only 5 columns	
				if(a!=56){
					temp_5 = A[b][a+5];
					temp_6 = A[b][a+6];
					temp_7 = A[b][a+7];
				}
				//Now transpose and store these values in same column of matrix B
				B[a][b] = temp_0;
				B[a+1][b] = temp_1;
				B[a+2][b] = temp_2;
				B[a+3][b] = temp_3;
				B[a+4][b] = temp_4;
				// If we have reached the last block we don't need to transpose the set of columns that d not exist in A
				if(a!=56){
					B[a+5][b] = temp_5;
					B[a+6][b] = temp_6;
					B[a+7][b] = temp_7;
				}
		   			
                        }
                }
        }

	ENSURES(is_transpose(M, N, A, B));
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    REQUIRES(M > 0);
    REQUIRES(N > 0);

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

    ENSURES(is_transpose(M, N, A, B));
}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

