/*
 * Name : Kavya Srinet
 * andrew id : ksrinet
 */

#include "cachelab.h"
#include <stdlib.h>
#include <stdio.h>
#include <getopt.h>
#include <unistd.h>
#include <string.h>

/*define the attributes of a line in cache*/
typedef struct {
	int last_used;
	int valid;
	int tag;
}cache_line;

/*define parameters of a cache set*/
typedef struct {
	cache_line *lines; /*a set of lines*/
}cache_set;

/*define parameters of a cache*/
typedef struct {
	int sets_no; /*number of sets per cache*/
	int lines_no; /*number of lines per set*/
	cache_set *sets; /*set of sets*/
}cache;

/*define the 64 bit address type*/
typedef unsigned long long int addr_64_bit;


void get_usage();
cache set_up_cache(int no_of_sets, int no_of_lines);
int evaluate_trace(cache *simulated_cache, unsigned long long int address, char operation, int s, int b);
unsigned long long get_set_index(addr_64_bit addr, int s, int b);
addr_64_bit get_tag(addr_64_bit addr, int s, int b);
int get_lru_index(cache *test_cache, int set_no);
int get_recent_stamp(cache *test_cache, int set_no);
void free_allocations(cache *test_cache);
/*total number of hits, misses and evicts*/
int total_hits = 0;
int total_misses = 0;
int total_evicts = 0;

int main(int argc, char *argv[]){
	cache simulated_cache; /*Create a cache that will be simulating a real cache*/
	FILE *read_trace_file; /*the file we will be reading from*/
	char trace[120]; /*read the name of trace file into trace*/
	char trace_line[120]; /*read each line from trace in this*/
	char operation;
	int s, b, E, v_option, no_of_sets, block_size;
	int status_msg;
	addr_64_bit address;
	int n_opt, count_opt;
	/*Read the input command line arguments  to read s , b , E and name of tracefile*/
        while((n_opt = getopt(argc, argv, "s:E:b:t:v")) != -1){
                switch(n_opt){
                case 's':
                        s = atoi(optarg); /*read the value of s*/
                        count_opt = count_opt + 1; /*count total number of perands given*/
                        break;
                case 'E':
                        E = atoi(optarg); /*read value of E*/
                        count_opt = count_opt + 1;
                        break;
                case 'b':
                        b = atoi(optarg); /*read value of b*/
                        count_opt = count_opt + 1;
                        break;
                case 't':
                        strcpy(trace,optarg);/*read the name of trace file*/
                        count_opt = count_opt + 1;
                        break;
                case 'v':
                        v_option = 1;/*if this option we will have to provide verbosity details if user enters this option*/
                        break;
                default:
                        get_usage();/*if user did not enter anything, display a detailed list of how to use ./csim*/
                        exit(-1);
                        break;
        	}
	}
	/*if user entered less than the four essentials arguments viz. s, b , E,t , display an error and usage*/
        if (count_opt < 4){
                printf("Missing some command line arguments\n ");
                get_usage();
                exit(-1);
        }
	
	no_of_sets = (1 << s);/*number of sets is 2^s */
	block_size = (1 << b);	/*number of bytes per block is 2^b*/
	simulated_cache = set_up_cache(no_of_sets, E);/*initiate and build a new cache*/
	read_trace_file = fopen(trace, "r");/*open the trace file in read mode*/
	if(!read_trace_file){
		printf("Cannot open the file %s \n",trace);
		return -1;
	}
	if(read_trace_file != NULL){
		/*read the file line by line*/
		while(fgets(trace_line, 120, read_trace_file) != NULL){
			if(trace_line[0] == ' '){
				/*if M, S or L instruction , read it, avoid I instructions*/
				sscanf(trace_line," %c %llx", &operation, &address);/*Read the operation name and associated address*/
				status_msg = evaluate_trace(&simulated_cache, address, operation, s, b);/*calculate misses, hits and evicts for the instruction*/
				/*if user entered v, display results in verbose format*/
				if(v_option == 1){
					switch (status_msg){/*print status msg returned by evaluate_trace*/
					case 1:
						printf("%s Hit\n", trace_line + 1);/*Hit and number of hits*/
						break;
					case 2:
						printf("%s Miss then Hit\n", trace_line + 1);
                                                break;
					case 3:
						printf("%s Miss\n", trace_line + 1);
                                                break;
					case 4:
						printf("%s Miss Evict then Hit\n", trace_line + 1);
                                                break;
					case 5:
						printf("%s Miss then Evict\n", trace_line + 1);
                                                break;
					default:
						break;
					}
				}
			}
		}
	}
	fclose(read_trace_file);/*close the opened file*/
	printSummary(total_hits, total_misses, total_evicts);/*Total number of hits, misses and evicts are in the global variables, call printSummary with them*/
	free_allocations(&simulated_cache);
	return 0;

}

/*Print a detailed usage of ./csim*/
void get_usage(){
	printf("Usage: ./csim [-h] [-v] -s <s> -E <E> -b <b> -t <tracefile>\n \
	• -h: Optional help flag that prints usage info\n \
	• -v: Optional verbose flag that displays trace info \n \
	• -s <s>: Number of set index bits (S = 2^s is the number of sets) \n \
	• -E <E>: Associativity (number of lines per set) \n \
	• -b <b>: Number of block bits (B = 2^b is the block size) \n \
	• -t <tracefile>: Name of the valgrind trace to replay\n");
	exit(0);
}

/*Initialize and set up cache with size allocated for all sets and lines and all attributes set to zero*/
cache set_up_cache(int no_of_sets, int no_of_lines){
	cache cache_temp;
	int i,j;
	cache_temp.sets_no = no_of_sets; //set the number of sets
	cache_temp.lines_no = no_of_lines; //set the number of lines per set
	cache_temp.sets = (cache_set *) malloc(sizeof(cache_set) * no_of_sets); //allocate memory to the sets
	for(i = 0; i < no_of_sets; i++){
		cache_temp.sets[i].lines = (cache_line *) malloc(sizeof(cache_line) * no_of_lines);//allocate memory to each line in a set
		//set each attribute of a line to zero
		for(j =0; j < no_of_lines; j++){
			cache_temp.sets[i].lines[j].last_used = 0;
			cache_temp.sets[i].lines[j].valid = 0;
			cache_temp.sets[i].lines[j].tag = 0;
		}	
	}
	return cache_temp;
}

/*We calculate the total number of hits, misses and evicts*/
int evaluate_trace(cache *simulated_cache, addr_64_bit address, char operation, int s, int b){
	unsigned long long set_no;
	addr_64_bit tag; // As addresses here are 64 bits
	int i;
	int most_recent, lru_index;
	set_no = get_set_index(address, s, b); //find the target set number 
	tag = get_tag(address, s, b); //find the target tag in a set
	//Now we traverse through each line of the set to find a valid and matching tag line
	for (i = 0; i < simulated_cache->lines_no; i++){
		if((simulated_cache->sets[set_no].lines[i].valid == 1) && (simulated_cache->sets[set_no].lines[i].tag == tag)){
			/*direct hit as the line is valid and has matching tag*/
			if(operation == 'M'){ //Operation Modify
				total_hits = total_hits + 2; //Hit on Load and hit on store
			}
			else{
				total_hits = total_hits + 1; //Hit on Load or store
			}
		most_recent = get_recent_stamp(simulated_cache, set_no); //get the most recently used value
		simulated_cache->sets[set_no].lines[i].last_used = most_recent + 1; //Make this line most recently used
		return 1; /*Hit*/
		}	
	}

	/*Not a hit, a miss"*/
	total_misses = total_misses + 1;
	/*see if there is an empty line where the new block can be loaded*/
	for (i = 0; i < simulated_cache->lines_no; i++){
                if(simulated_cache->sets[set_no].lines[i].valid == 0){
			/*found an empty line, get the block here*/
			simulated_cache->sets[set_no].lines[i].valid = 1;
			simulated_cache->sets[set_no].lines[i].tag = tag;
			most_recent = get_recent_stamp(simulated_cache, set_no);
	                simulated_cache->sets[set_no].lines[i].last_used = most_recent + 1; // Mke this line most recently used
			if(operation == 'M'){ //Operation Modify
                                total_hits = total_hits + 1; //One has been a miss, the next one hit
				return 2; /* Miss and then Hit*/
                        }
                        else{
                                return 3; /*Miss*/ //Direct miss for Load or Store
                        }

		}
	}

	/*If there is amiss and no empty lines are available, evict a line using LRU policy*/
	total_evicts = total_evicts + 1;
	lru_index = get_lru_index(simulated_cache, set_no); //Get the least recently used index
	//Found the line to evict , get the block here
	simulated_cache->sets[set_no].lines[lru_index].valid = 1;
        simulated_cache->sets[set_no].lines[lru_index].tag = tag;
        most_recent = get_recent_stamp(simulated_cache, set_no);
        simulated_cache->sets[set_no].lines[lru_index].last_used = most_recent + 1; //Mark as most recently used
	if(operation == 'M'){ //operation Modify
                                total_hits = total_hits + 1;
                                return 4; /*Miss Evict then Hit*/
                        }
                        else{
                                return 5; /*Miss then Evict*/
                        }


return 0;
}

/*Get the target set index from the address*/
unsigned long long get_set_index(addr_64_bit addr, int s, int b){
	unsigned long long set_index, set_temp;
	int tag = (64 - s - b); //number of address bit(64) is is t + s + b
	set_temp = (addr << tag);
	set_index= set_temp >> (tag + b); //get the set index value
	return set_index;
}

/*Get the tag value by masking s and b bits*/
addr_64_bit get_tag(addr_64_bit addr, int s, int b){
	addr_64_bit tag;
	tag = addr >> (s +b); //As address bits = t + s + b in sequence
	return tag;
}

/*Get the index of the least recently used line*/
int get_lru_index(cache *test_cache, int set_no){
	int i,least_used_index, min_used;
	min_used = test_cache->sets[set_no].lines[0].last_used; //set min_used as the first element
	least_used_index = 0;
	//Find the minimum value of last_used value and set it as min_used and return its index
	for(i = 1; i < test_cache->lines_no; i++){
		if(min_used > test_cache->sets[set_no].lines[i].last_used){
			min_used = test_cache->sets[set_no].lines[i].last_used;
			least_used_index = i;
		}
	}
	return least_used_index;
}

/*Get the value of stamp of most recently used line*/
int get_recent_stamp(cache *test_cache, int set_no){
	int i,most_recent;
	most_recent = test_cache->sets[set_no].lines[0].last_used;
	//Find the last_used stamp of the line most recently used
	for(i = 1; i < test_cache->lines_no; i++){
                if(most_recent < test_cache->sets[set_no].lines[i].last_used){
                        most_recent = test_cache->sets[set_no].lines[i].last_used;
                }
        }
	return most_recent;
}

/*Free all the memory allocations done for the cache */
void free_allocations(cache *test_cache){
	int i;
	//Free memory allocated for all lines first
	for(i = 0; i < test_cache->sets_no;i++){
		if(test_cache->sets[i].lines){
			free(test_cache->sets[i].lines);
		}
	}
	//Free the memory allocated for sets
	if(test_cache->sets){
		free(test_cache->sets);
	}
}
